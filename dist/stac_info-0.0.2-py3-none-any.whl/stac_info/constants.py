GHANA_BOUNDING_BOX = [-3.25, 4.75, 1.25, 11.25]
AWS_SEARCH_URL = "https://earth-search.aws.element84.com/v0/search"
ONE_IMAGE_BBOX = [-1.240425,8.168333,-1.008854,8.280974]